# Layouts and Positioning

### Task 1

1. Create a simple layout with 30% width sidebar on the right side of the page

### Task 2

1. Create a simple layout with 30% width sidebar on the left side of the page

### Task 3

1. Create a nice dropdown menu with multiple levels

### Task 4

1. Create a nice looking gallery layout
