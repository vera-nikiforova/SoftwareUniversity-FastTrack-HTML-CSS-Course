# Advanced Layouts and Positioning

### Task 1

Walk through all demos and recreate each one. Make sure that you understand how and why we are doing the things we do. Questions can be posted in the forum or directly to me on email.

### Task 2

Try to come up with strange and possibly impossible layouts. Have a go at creating them. Then send me an email with your layout ideas and questions at koko@rhyndo.com

