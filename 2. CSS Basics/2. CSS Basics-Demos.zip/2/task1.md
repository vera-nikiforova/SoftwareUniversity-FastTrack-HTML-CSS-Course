# CSS Basics

## Practice

### Task 1

1. Create a simple HTML document. One h1 and a few paragraphs.
2. Remove margin and padding from all elements
3. Change the Font of the document
4. Add a nice and simple body background
5. Add padding-bottom to all paragraphs
6. Add a .wrapper div around all elements
7. Add padding to the .wrapper div
8. Style all paragraphs in the .wrapper div to have 1px border, white background and margin bottom.
9. 

### Task 2
1. Go to http://en.wikipedia.org/wiki/Giraffe
2. Copy all text and create the Headings and Paragraphs in a simple HTML document
3. Add all the images at the appropriate places.

## Homework

### Task 1
### Task 2
### Task 3
